#!/usr/bin/python
import numpy as np
with open('stats2.txt','r') as f:
    adv = np.genfromtxt(f,dtype=None,delimiter = '\n')
with open('uyears.txt','r') as f:
    y = np.genfromtxt(f,dtype = None)
with open('ucrops.txt','r') as f:
    cp = np.genfromtxt(f,dtype= None)
with open('ucroptypes.txt','r') as f:
    cpt = np.genfromtxt(f,dtype=None)
with open('prob.txt','r')as f:
    pb = np.genfromtxt(f,dtype = None,delimiter = ';')

d = [list() for i in range(len(pb))]
for i in range(len(adv)):
    for j in range(len(pb)):
        if pb[j][0] in adv[i]:
            d[j].append(y[i]+"  "+cp[i]+"   "+cpt[i]+"  "+pb[j][0])

for i in range(len(pb)):
    np.savetxt('probSpecific/'+pb[i][0]+'.txt',d[i],fmt='%s')


