#!/usr/bin/python
import numpy as np
from sklearn.datasets import load_files
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import cross_val_score
from sklearn.metrics import classification_report,confusion_matrix
from sklearn import preprocessing
d = load_files('train 3')
x= d.data
y = d.target
#print len(x),len(y)
#print x
for i in range(len(x)):
	x[i] = x[i].split()
	for j in range(len(x[i])):
		x[i][j] = float(x[i][j])
x= preprocessing.scale(x)
x_train, x_test, y_train,y_test = train_test_split(x,y,test_size=0.2)
alp=1
#out=[[0 for i in range(2)] for j in range(((100-5)/5))]	
for nh in range(5,100,5):
	nn = MLPClassifier(activation='logistic',solver='sgd',learning_rate='adaptive',learning_rate_init=alp,hidden_layer_sizes=(nh))
	nn.fit(x_train,y_train)
	print nh,nn.score(x_test,y_test)*100,nn.score(x_train,y_train)*100
