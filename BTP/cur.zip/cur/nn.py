#!/usr/bin/python
import numpy as np
from sklearn.datasets import load_files
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import cross_val_score
from sklearn import preprocessing
d = load_files('train 2a')
x= d.data
y = d.target
#print len(x),len(y)
#print x
for i in range(len(x)):
    x[i] = x[i].split()
    for j in range(len(x[i])):
        x[i][j] = float(x[i][j])
x= preprocessing.scale(x)
print len(x)
x_train, x_test, y_train,y_test = train_test_split(x,y,test_size=0.2)
'''
ns=700
x_train = x[ns:]
x_test = x[:ns]
y_train = y[ns:]
y_test = y[:ns]
'''
mx=0
mxa=0
mxh=0
mxh1=0
cval=[]
cval1=[]
itr=0
a=1
trainacc = []
testacc = []
tmp = 0
aopt = 0
mat = []
for nh in range(5,105,5):
    for nh1 in range(5,55,5):
    #tm = []
        for nh2 in range(5,55,5):
#            for nh3 in range(5,55,5):
#                for nh4 in range(5,55,5):
                    for a in range(-5,2):
                        tmp2=[]
                        alp = 10**a;
    #alp = a/float(10)
#        for nh1 in range(5,55,5):
                        nn = MLPClassifier(activation='logistic',alpha=0.0001,solver='sgd',learning_rate='adaptive',learning_rate_init=alp,hidden_layer_sizes=(nh,nh1,nh2),max_iter=1000)      
                        nn.fit(x_train,y_train)
                        trsc = nn.score(x_train,y_train)
                        tmp2.append(alp)
            #trainacc.append(trsc)
                        tmp2.append(trsc)
                        sc = nn.score(x_test,y_test)
            #testacc.append(sc)
                        tmp2.append(sc)
            #tm.append(str(trsc)+";"+str(sc))
                        if sc>tmp:
                            tmp = sc
                            aopt = alp
#            pred = nn.predict(x_test)
#            a = y_test
        #ct=0
        #for i in range(len(a)):
        #    if pred[i]==a[i]:
        #        ct+=1
        #print ct/float(len(a))
            #scores = cross_val_score(nn,x,y,cv = 5)
                        itr+=1
                        print "regularization parameter: %f  no.of hidden units: %d %d %d %d %d train accuracy: %f test accuracy: %f"%(alp,nh,nh1,nh2,nh,nh,100*trsc,100*sc),"%"
#        cval1.append([alp,nh,sc])
                        if sc>mx:
                            mx = sc
                            mxh=nh   
                            mxa = a
                        mat.append(tmp2)
    #nnopt = MLPClassifier(activation='logistic',alpha=aopt,solver='sgd',learning_rate='adaptive',learning_rate_init=1,hidden_layer_sizes=(nh))
#wts = 
print mxh,mxa,mx
np.savetxt('alpha2.txt',mat,delimiter='\t',fmt='%s')
